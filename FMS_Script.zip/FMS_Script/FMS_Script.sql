
--------------------------------------------------------
--  DDL for Table FMS_METADATA
--------------------------------------------------------

  CREATE TABLE "NFMS"."FMS_METADATA" 
   (	"ID" NUMBER, 
	"LOOKUPCODE" VARCHAR2(50 BYTE), 
	"LOOKUPCODEID" VARCHAR2(50 BYTE), 
	"LANGUAGE" VARCHAR2(20 BYTE) DEFAULT 'VN', 
	"VALUE" VARCHAR2(500 BYTE), 
	"ORDERBY" VARCHAR2(10 BYTE) DEFAULT 0, 
	"ISSHOW" VARCHAR2(10 BYTE) DEFAULT 'Y',
	"CREATED_DT" DATE, 
	"CREATED_USER" VARCHAR2(100 BYTE), 
	"UPDATED_DT" DATE, 
	"UPDATED_USER" VARCHAR2(100 BYTE)
   ) ;
   
--------------------------------------------------------
--  DDL for Index FMS_METADATA_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "NFMS"."FMS_METADATA_PK" ON "NFMS"."FMS_METADATA" ("ID") 
  ;
--------------------------------------------------------
--  DDL for Index FMS_METADATA_INDEX
--------------------------------------------------------

  CREATE INDEX "NFMS"."FMS_METADATA_INDEX" ON "NFMS"."FMS_METADATA" ("ID", "LOOKUPCODE", "LOOKUPCODEID") 
  ;
--------------------------------------------------------
--  Constraints for Table FMS_METADATA
--------------------------------------------------------

  ALTER TABLE "NFMS"."FMS_METADATA" MODIFY ("LOOKUPCODE" NOT NULL ENABLE);
  ALTER TABLE "NFMS"."FMS_METADATA" MODIFY ("LOOKUPCODEID" NOT NULL ENABLE);
  ALTER TABLE "NFMS"."FMS_METADATA" ADD CONSTRAINT "FMS_METADATA_PK" PRIMARY KEY ("ID")
  USING INDEX ENABLE;

--------------------------------------------------------
--  DDL for Sequence FMS_METADATA_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "NFMS"."FMS_METADATA_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1000 CACHE 20;
   
--------------------------------------------------------
--  DDL for Table FMS_AUTH_USER
--------------------------------------------------------

  CREATE TABLE "NFMS"."FMS_AUTH_USER" 
   (	"ID" NUMBER, 
	"USERNAME" VARCHAR2(50 BYTE), 
	"PASSWORD" VARCHAR2(500 BYTE), 
	"FULLNAME" VARCHAR2(100 BYTE), 
	"EMAIL" VARCHAR2(100 BYTE), 
	"STATUS" VARCHAR2(50 BYTE), 
	"CONFIGURE" VARCHAR2(100 BYTE), 
	"CREATED_DT" DATE, 
	"CREATED_USER" VARCHAR2(100 BYTE), 
	"UPDATED_DT" DATE, 
	"UPDATED_USER" VARCHAR2(100 BYTE)
   ) ;
--------------------------------------------------------
--  DDL for Index FMS_AUTH_USER_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "NFMS"."FMS_AUTH_USER_PK" ON "NFMS"."FMS_AUTH_USER" ("ID") 
  ;
--------------------------------------------------------
--  DDL for Index FMS_AUTH_USER_INDEX
--------------------------------------------------------

  CREATE INDEX "NFMS"."FMS_AUTH_USER_INDEX" ON "NFMS"."FMS_AUTH_USER" ("ID", "USERNAME", "CONFIGURE") 
  ;
--------------------------------------------------------
--  Constraints for Table FMS_AUTH_USER
--------------------------------------------------------

  ALTER TABLE "NFMS"."FMS_AUTH_USER" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "NFMS"."FMS_AUTH_USER" MODIFY ("USERNAME" NOT NULL ENABLE);  
  ALTER TABLE "NFMS"."FMS_AUTH_USER" ADD CONSTRAINT "FMS_AUTH_USER_PK" PRIMARY KEY ("ID")
  USING INDEX  ENABLE;
  
--------------------------------------------------------
--  DDL for Sequence FMS_AUTH_USER_SEQ
--------------------------------------------------------

CREATE SEQUENCE  "NFMS"."FMS_AUTH_USER_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1000 CACHE 20;

--------------------------------------------------------
--  DDL for Table FMS_QUEUE_MAS
--------------------------------------------------------
CREATE TABLE "NFMS"."FMS_QUEUE_MAS" 
(	"ID" NUMBER, 
	"UPLOAD_DT" DATE, 
	"APPL_REF_NUM" VARCHAR2(100 BYTE), 
	"PRODUCT_CAT" VARCHAR2(50 BYTE), 
	"PRODUCT" VARCHAR2(100 BYTE), 
	"LOS_DT" DATE, 
	"SOURCE" VARCHAR2(100 BYTE), 
	"INPUTTER_ID" VARCHAR2(100 BYTE), 
	"INPUTTER_NAME" VARCHAR2(200 BYTE), 
	"DEPARTMENT" VARCHAR2(100 BYTE), 
	"COMPAIGN_CODE" VARCHAR2(100 BYTE), 
	"PRIORITY_FLAG" VARCHAR2(50 BYTE), 
	
	"CIF" VARCHAR2(100 BYTE), 
	"FULL_NAME" VARCHAR2(200 BYTE), 
	"DATE_OF_BIRTH" DATE, 
	"NATIONAL_ID" VARCHAR2(100 BYTE), 
	"COMPANY_NAME" VARCHAR2(500 BYTE), 
	"COMPANY_TAX" VARCHAR2(100 BYTE), 
	"COMPANY_CATEGORY" VARCHAR2(100 BYTE), 
	
	"SALES_USER_ID" VARCHAR2(100 BYTE),
	"CITY" VARCHAR2(200 BYTE),
	"APPLICATION_STATUS" VARCHAR2(200 BYTE),
	"COLLECTION_STATUS" VARCHAR2(200 BYTE),
	"DISBURSED_AMT" NUMBER DEFAULT 0,
	"AGE" NUMBER DEFAULT 0,
	"INCOME_AMT" NUMBER DEFAULT 0,
	"AUTH_DATE" DATE,
	"BOOKED_AMT" NUMBER DEFAULT 0,
	
	"COMMENTS" VARCHAR2(4000 BYTE), 
	"CREATED_DT" DATE, 
	"CREATED_USER" VARCHAR2(100 BYTE), 
	"UPDATED_DT" DATE, 
	"UPDATED_USER" VARCHAR2(100 BYTE)
) ;
--------------------------------------------------------
--  DDL for Index FMS_QUEUE_MAS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "NFMS"."FMS_QUEUE_MAS_PK" ON "NFMS"."FMS_QUEUE_MAS" ("ID") 
  ;
--------------------------------------------------------
--  DDL for Index FMS_QUEUE_MAS_INDEX
--------------------------------------------------------

  CREATE INDEX "NFMS"."FMS_QUEUE_MAS_INDEX" ON "NFMS"."FMS_QUEUE_MAS" ("ID", "UPLOAD_DT", "APPL_REF_NUM", "LOS_DT", "CIF", "NATIONAL_ID", "COMPANY_TAX") 
  ;
--------------------------------------------------------
--  Constraints for Table FMS_QUEUE_MAS
--------------------------------------------------------

  ALTER TABLE "NFMS"."FMS_QUEUE_MAS" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "NFMS"."FMS_QUEUE_MAS" MODIFY ("UPLOAD_DT" NOT NULL ENABLE);
  ALTER TABLE "NFMS"."FMS_QUEUE_MAS" ADD CONSTRAINT "FMS_QUEUE_MAS_PK" PRIMARY KEY ("ID")
  USING INDEX  ENABLE;

--------------------------------------------------------
--  DDL for Sequence FMS_QUEUE_MAS_SEQ
--------------------------------------------------------

CREATE SEQUENCE  "NFMS"."FMS_QUEUE_MAS_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1000 CACHE 20;

--------------------------------------------------------
--  DDL for Table FMS_SALE_MAS
--------------------------------------------------------

CREATE TABLE "NFMS"."FMS_SALE_MAS" 
(	"ID" NUMBER, 
"SALES_USER_ID" VARCHAR2(100 BYTE), 
"SALES_NAME" VARCHAR2(100 BYTE), 
"SALES_NATION_ID" VARCHAR2(100 BYTE), 
"TEAM_NAME" VARCHAR2(200 BYTE), 
"CHANNEL_CODE" VARCHAR2(100 BYTE), 
"CHANNEL_NAME" VARCHAR2(200 BYTE), 
"JOB_TYPE_CODE" VARCHAR2(100 BYTE), 
"JOB_TYPE_NAME" VARCHAR2(200 BYTE), 
"AGENT_STATUS" VARCHAR2(100 BYTE), 
"AGENT_ID" VARCHAR2(100 BYTE), 

"CREATED_DT" DATE, 
"CREATED_USER" VARCHAR2(100 BYTE), 
"UPDATED_DT" DATE, 
"UPDATED_USER" VARCHAR2(100 BYTE)
) ;
--------------------------------------------------------
--  DDL for Index FMS_SALE_MAS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "NFMS"."FMS_SALE_MAS_PK" ON "NFMS"."FMS_SALE_MAS" ("ID") 
  ;
--------------------------------------------------------
--  DDL for Index FMS_SALE_MAS_INDEX
--------------------------------------------------------

  CREATE INDEX "NFMS"."FMS_SALE_MAS_INDEX" ON "NFMS"."FMS_SALE_MAS" ("ID", "SALES_USER_ID") 
  ;
--------------------------------------------------------
--  Constraints for Table FMS_SALE_MAS
--------------------------------------------------------

  ALTER TABLE "NFMS"."FMS_SALE_MAS" MODIFY ("ID" NOT NULL ENABLE);
  --ALTER TABLE "NFMS"."FMS_SALE_MAS" MODIFY ("SALES_USER_ID" NOT NULL ENABLE);
  ALTER TABLE "NFMS"."FMS_SALE_MAS" ADD CONSTRAINT "FMS_SALE_MAS_PK" PRIMARY KEY ("ID")
  USING INDEX  ENABLE;

--------------------------------------------------------
--  DDL for Sequence FMS_SALE_MAS_SEQ
--------------------------------------------------------

CREATE SEQUENCE  "NFMS"."FMS_SALE_MAS_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1000 CACHE 20;

--------------------------------------------------------
--  DDL for Table FMS_QUEUE_INF
--------------------------------------------------------

  CREATE TABLE "NFMS"."FMS_QUEUE_INF" 
   (	"ID" NUMBER, 
    "REF_ID" VARCHAR2(100 BYTE), 
	"REF_SALES_ID" VARCHAR2(100 BYTE),
	"DOC_ID" VARCHAR2(200 BYTE), 
	"STATUS_CODE" VARCHAR2(50 BYTE), 
	"ASSIGNED_DT" DATE, 
	"ASSIGNED_USER" VARCHAR2(100 BYTE), 

	"ACTION_AGAINST_CUSTOMER" VARCHAR2(100 BYTE), 
	"ACTION_AGAINST_COMPANY" VARCHAR2(100 BYTE), 
	"ACTION_AGAINST_SR" VARCHAR2(100 BYTE), 
	
	"FV_NAME" VARCHAR2(200 BYTE), 
	"FV_NATION_ID" VARCHAR2(100 BYTE), 
	"ACTION_AGAINST_FV" VARCHAR2(100 BYTE), 
	
	"TC_NAME" VARCHAR2(200 BYTE), 
	"TC_NATION_ID" VARCHAR2(100 BYTE), 
	"ACTION_AGAINST_TC" VARCHAR2(100 BYTE), 
	
	"AGENCY_NAME" VARCHAR2(200 BYTE), 
	"AGENCY_TAX_CODE" VARCHAR2(100 BYTE), 
	"ACTION_AGAINST_AGENCY" VARCHAR2(100 BYTE), 
	
	"FRAUD_CONFIRMATION" VARCHAR2(4000 BYTE), 
	"FRAUD_TYPE" VARCHAR2(100 BYTE), 
	"FRAUD_TYPE_DETAIL" VARCHAR2(100 BYTE), 
	"FRAUD_TOTAL_ACTION" VARCHAR2(500 BYTE), 
	
	"SUBMISSION_DT" DATE, 
	"AUTHORIZER_REMARKS" VARCHAR2(4000 BYTE), 
	
	"APPROVAL_DT" DATE, 
	"APPROVAL_USER" VARCHAR2(100 BYTE), 
	"CLONED_ID" NUMBER, 
	"CLONED_DT" DATE, 
	"CLONED_USER" VARCHAR2(100 BYTE), 
	
	"STATUS_NOTEPAD" VARCHAR2(50 BYTE), 
	"STATUS_BACKLIST" VARCHAR2(50 BYTE), 
	"STATUS_AIS_AGENT" VARCHAR2(50 BYTE), 
	"REMARKS" VARCHAR2(4000 BYTE), 

	"TOTAL_ACTION" VARCHAR2(500 BYTE), 
	"CREATED_DT" DATE, 
	"CREATED_USER" VARCHAR2(100 BYTE), 
	"UPDATED_DT" DATE, 
	"UPDATED_USER" VARCHAR2(100 BYTE)
   ) ;
--------------------------------------------------------
--  DDL for Index FMS_QUEUE_INF_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "NFMS"."FMS_QUEUE_INF_PK" ON "NFMS"."FMS_QUEUE_INF" ("ID") 
  ;
--------------------------------------------------------
--  DDL for Index FMS_QUEUE_INF_INDEX
--------------------------------------------------------

  CREATE INDEX "NFMS"."FMS_QUEUE_INF_INDEX" ON "NFMS"."FMS_QUEUE_INF" ("ID", "REF_ID", "REF_SALES_ID", "STATUS_CODE", "ASSIGNED_DT", "ASSIGNED_USER", "APPROVAL_DT", "ACTION_AGAINST_SR", "ACTION_AGAINST_FV", "ACTION_AGAINST_TC", "ACTION_AGAINST_CUSTOMER", "ACTION_AGAINST_COMPANY") 
  ;
--------------------------------------------------------
--  Constraints for Table FMS_QUEUE_INF
--------------------------------------------------------

  ALTER TABLE "NFMS"."FMS_QUEUE_INF" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "NFMS"."FMS_QUEUE_INF" MODIFY ("REF_ID" NOT NULL ENABLE);
  ALTER TABLE "NFMS"."FMS_QUEUE_INF" MODIFY ("STATUS_CODE" NOT NULL ENABLE);
  ALTER TABLE "NFMS"."FMS_QUEUE_INF" ADD CONSTRAINT "FMS_QUEUE_INF_PK" PRIMARY KEY ("ID")
  USING INDEX  ENABLE;
  
--------------------------------------------------------
--  DDL for Sequence FMS_QUEUE_INF_SEQ
--------------------------------------------------------

CREATE SEQUENCE  "NFMS"."FMS_QUEUE_INF_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1000 CACHE 20;

--------------------------------------------------------
--  DDL for Table FMS_DOC_MAS
--------------------------------------------------------
CREATE TABLE "NFMS"."FMS_DOC_MAS" 
(	"ID" NUMBER, 
"DOC_ID" VARCHAR2(100 BYTE), 
"FILE_NAME" VARCHAR2(500 BYTE), 
"FILE_PATH" VARCHAR2(200 BYTE), 
"FILE_TYPE" VARCHAR2(100 BYTE), 
"REMARKS" VARCHAR2(500 BYTE), 

"CREATED_DT" DATE, 
"CREATED_USER" VARCHAR2(100 BYTE), 
"UPDATED_DT" DATE, 
"UPDATED_USER" VARCHAR2(100 BYTE)
) ;
--------------------------------------------------------
--  DDL for Index FMS_DOC_MAS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "NFMS"."FMS_DOC_MAS_PK" ON "NFMS"."FMS_DOC_MAS" ("ID") 
  ;
--------------------------------------------------------
--  DDL for Index FMS_DOC_MAS_INDEX
--------------------------------------------------------

  CREATE INDEX "NFMS"."FMS_DOC_MAS_INDEX" ON "NFMS"."FMS_DOC_MAS" ("ID", "DOC_ID") 
  ;
--------------------------------------------------------
--  Constraints for Table FMS_DOC_MAS
--------------------------------------------------------

  ALTER TABLE "NFMS"."FMS_DOC_MAS" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "NFMS"."FMS_DOC_MAS" MODIFY ("DOC_ID" NOT NULL ENABLE);
  ALTER TABLE "NFMS"."FMS_DOC_MAS" ADD CONSTRAINT "FMS_DOC_MAS_PK" PRIMARY KEY ("ID")
  USING INDEX  ENABLE;

--------------------------------------------------------
--  DDL for Sequence FMS_DOC_MAS_SEQ
--------------------------------------------------------

CREATE SEQUENCE  "NFMS"."FMS_DOC_MAS_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1000 CACHE 20;

--------------------------------------------------------
--  DDL for Table FMS_QUEUE_MAS_A
--------------------------------------------------------

CREATE TABLE "NFMS"."FMS_QUEUE_MAS_A" 
(	"ID" NUMBER GENERATED ALWAYS AS IDENTITY MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20, 
	"REF_ID" NUMBER, 
	"UPLOAD_DT" DATE, 
	"APPL_REF_NUM" VARCHAR2(100 BYTE), 
	"PRODUCT_CAT" VARCHAR2(50 BYTE), 
	"PRODUCT" VARCHAR2(100 BYTE), 
	"LOS_DT" DATE, 
	"SOURCE" VARCHAR2(100 BYTE), 
	"INPUTTER_ID" VARCHAR2(100 BYTE), 
	"INPUTTER_NAME" VARCHAR2(200 BYTE), 
	"DEPARTMENT" VARCHAR2(100 BYTE), 
	"COMPAIGN_CODE" VARCHAR2(100 BYTE), 
	"PRIORITY_FLAG" VARCHAR2(50 BYTE), 
	
	"CIF" VARCHAR2(100 BYTE), 
	"FULL_NAME" VARCHAR2(200 BYTE), 
	"DATE_OF_BIRTH" DATE, 
	"NATIONAL_ID" VARCHAR2(100 BYTE), 
	"COMPANY_NAME" VARCHAR2(500 BYTE), 
	"COMPANY_TAX" VARCHAR2(100 BYTE), 
	"COMPANY_CATEGORY" VARCHAR2(100 BYTE), 
	
	"SALES_USER_ID" VARCHAR2(100 BYTE),
	
	"COMMENTS" VARCHAR2(500 BYTE), 
	"CREATED_DT" DATE, 
	"CREATED_USER" VARCHAR2(100 BYTE), 
	"UPDATED_DT" DATE, 
	"UPDATED_USER" VARCHAR2(100 BYTE)
) ;


 CREATE UNIQUE INDEX "NFMS"."FMS_QUEUE_MAS_A_PK" ON "NFMS"."FMS_QUEUE_MAS_A" ("ID") 
  ;
--------------------------------------------------------
--  DDL for Index FMS_QUEUE_MAS_A_INDEX
--------------------------------------------------------

  CREATE INDEX "NFMS"."FMS_QUEUE_MAS_A_INDEX" ON "NFMS"."FMS_QUEUE_MAS_A" ("ID", "REF_ID", "UPLOAD_DT") 
  ;
--------------------------------------------------------
--  Constraints for Table FMS_QUEUE_MAS_A
--------------------------------------------------------

  ALTER TABLE "NFMS"."FMS_QUEUE_MAS_A" ADD CONSTRAINT "FMS_QUEUE_MAS_A_PK" PRIMARY KEY ("ID")
  USING INDEX  ENABLE;


--------------------------------------------------------
--  Trigger for Table FMS_QUEUE_MAS
--------------------------------------------------------

CREATE OR REPLACE TRIGGER "NFMS"."TRI_AFTER_UPDATE_FMS_QUEUE_MAS" 
AFTER UPDATE OF FULL_NAME, DATE_OF_BIRTH, NATIONAL_ID, COMPANY_NAME, COMPANY_TAX ON "NFMS"."FMS_QUEUE_MAS" FOR EACH ROW
BEGIN
    IF ( :old.FULL_NAME <> :new.FULL_NAME OR :old.DATE_OF_BIRTH <> :new.DATE_OF_BIRTH OR :old.NATIONAL_ID <> :new.NATIONAL_ID
            OR :old.COMPANY_NAME <> :new.COMPANY_NAME OR :old.COMPANY_TAX <> :new.COMPANY_TAX) THEN 
      -- Insert record into audit table
       INSERT INTO "NFMS"."FMS_QUEUE_MAS_A"
       ( REF_ID, FULL_NAME, DATE_OF_BIRTH, NATIONAL_ID, COMPANY_NAME, COMPANY_TAX, 
            CREATED_DT, CREATED_USER, UPDATED_DT, UPDATED_USER)
       VALUES
       ( :new.ID, :new.FULL_NAME, :new.DATE_OF_BIRTH, :new.NATIONAL_ID, :new.COMPANY_NAME, :new.COMPANY_TAX, 
            :new.UPDATED_DT, :new.UPDATED_USER, :new.UPDATED_DT, :new.UPDATED_USER);
    END IF;
END;

--------------------------------------------------------
--  DDL for Table FMS_TRACK_ESB_MAS
--------------------------------------------------------

CREATE TABLE "NFMS"."FMS_TRACK_ESB_MAS" 
(	"ID" NUMBER, 
"URL" VARCHAR2(500 BYTE), 
"START_DT" DATE, 
"END_DT" DATE, 
"DURATION" VARCHAR2(50 BYTE), 
"REQUEST" CLOB, 
"RESPONSE" CLOB, 
"STATUS" VARCHAR2(50 BYTE), 

"CREATED_DT" DATE, 
"CREATED_USER" VARCHAR2(100 BYTE), 
"UPDATED_DT" DATE, 
"UPDATED_USER" VARCHAR2(100 BYTE)
) ;
   
--------------------------------------------------------
--  DDL for Index FMS_TRACK_ESB_MAS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "NFMS"."FMS_TRACK_ESB_MAS_PK" ON "NFMS"."FMS_TRACK_ESB_MAS" ("ID") 
  ;

--------------------------------------------------------
--  Constraints for Table FMS_TRACK_ESB_MAS
--------------------------------------------------------

  ALTER TABLE "NFMS"."FMS_TRACK_ESB_MAS" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "NFMS"."FMS_TRACK_ESB_MAS" ADD CONSTRAINT "FMS_TRACK_ESB_MAS_PK" PRIMARY KEY ("ID")
  USING INDEX  ENABLE;

--------------------------------------------------------
--  DDL for Sequence FMS_TRACK_ESB_MAS_SEQ
--------------------------------------------------------

CREATE SEQUENCE  "NFMS"."FMS_TRACK_ESB_MAS_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1000 CACHE 20;
